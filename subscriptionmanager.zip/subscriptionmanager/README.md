# Subscription Management System

A full-stack **Subscription Management System** built with **Spring Boot**, **Spring Security**, **Thymeleaf**, **Hibernate/JPA**, and **MySQL**. The application enables users to manage subscription plans through a secure, role-based interface while providing administrators with complete control over users, plans, and subscriptions.

---

## Features

### User Features
- User registration and login
- Secure authentication using Spring Security
- View active and expired subscriptions
- View subscription plan details
- User dashboard with personalized information

### Admin Features
- Admin dashboard
- Manage subscription plans (Create, Update, Delete)
- View all registered users
- Update or delete user accounts
- Manage user subscriptions
- Delete subscriptions

### Security
- Role-based authorization (`ADMIN` and `USER`)
- Password encryption
- Secure login and logout
- Protected routes using Spring Security

### Additional Features
- Real-time notification toasts
- Seed data for quick testing
- Responsive user interface
- Clean MVC architecture

---

## Technologies Used

- Java 17
- Spring Boot
- Spring Security
- Spring Data JPA (Hibernate)
- Thymeleaf
- MySQL
- Maven
- HTML5
- CSS3
- JavaScript

---

## Project Structure

```text
src/
├── main/
│   ├── java/
│   │   └── com/example/subscriptionmanager/
│   │       ├── config/
│   │       ├── controller/
│   │       ├── model/
│   │       ├── repository/
│   │       ├── security/
│   │       └── service/
│   └── resources/
│       ├── static/
│       ├── templates/
│       └── application.properties

database/
└── setup.sql
```

---

## Database Configuration

1. Install and start MySQL Server.
2. Create a database named:

```sql
subscription
```

3. Execute the SQL script located in:

```
database/setup.sql
```

4. Update the database configuration in:

```
src/main/resources/application.properties
```

Example configuration:

```properties
spring.datasource.url=jdbc:mysql://localhost:3306/subscription
spring.datasource.username=your_mysql_username
spring.datasource.password=your_mysql_password
```

---

## Installation

Clone the repository:

```bash
git clone https://github.com/your-username/subscription-management-system.git
```

Navigate to the project folder:

```bash
cd subscription-management-system
```

Run the application:

```bash
mvn spring-boot:run
```

The application will start at:

```
http://localhost:8080
```

---

## Demo Login Credentials

### Admin

Email:
```
admin@submanager.com
```

Password:
```
admin123
```

### User

Email:
```
user@submanager.com
```

Password:
```
user123
```

---

## Future Enhancements

- Email notifications
- Payment gateway integration
- Subscription renewal reminders
- User profile management
- Analytics dashboard
- REST API support
- Docker deployment

---

## Author

**Neha S**

MCA Student | Java Full Stack Developer

---

## License

This project is developed for educational and learning purposes.