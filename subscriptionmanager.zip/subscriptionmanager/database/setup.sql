CREATE DATABASE IF NOT EXISTS subscription;

CREATE USER IF NOT EXISTS 'subapp_user'@'localhost' IDENTIFIED BY 'SubApp@2026Secure!';
CREATE USER IF NOT EXISTS 'subapp_user'@'127.0.0.1' IDENTIFIED BY 'SubApp@2026Secure!';
GRANT ALL PRIVILEGES ON subscription.* TO 'subapp_user'@'localhost';
GRANT ALL PRIVILEGES ON subscription.* TO 'subapp_user'@'127.0.0.1';
FLUSH PRIVILEGES;

USE subscription;

CREATE TABLE IF NOT EXISTS users (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(80) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role VARCHAR(10) NOT NULL
);

CREATE TABLE IF NOT EXISTS plans (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    plan_name VARCHAR(100) NOT NULL UNIQUE,
    price DECIMAL(10,2) NOT NULL,
    duration INT NOT NULL
);

CREATE TABLE IF NOT EXISTS subscriptions (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    plan_name VARCHAR(100) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    user_id BIGINT NOT NULL,
    plan_id BIGINT NOT NULL,
    CONSTRAINT fk_subscription_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_subscription_plan FOREIGN KEY (plan_id) REFERENCES plans(id) ON DELETE CASCADE
);
