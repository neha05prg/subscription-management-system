document.addEventListener("DOMContentLoaded", () => {
    const toasts = document.querySelectorAll(".toast");
    toasts.forEach((toast) => {
        setTimeout(() => {
            toast.style.transition = "opacity 0.4s";
            toast.style.opacity = "0";
        }, 3500);
    });

    document.querySelectorAll("[data-confirm]").forEach((el) => {
        el.addEventListener("click", (event) => {
            const message = el.getAttribute("data-confirm");
            if (!window.confirm(message)) {
                event.preventDefault();
            }
        });
    });

    // Smooth reveal on scroll.
    const revealItems = document.querySelectorAll(".reveal");
    if ("IntersectionObserver" in window) {
        const observer = new IntersectionObserver((entries) => {
            entries.forEach((entry) => {
                if (entry.isIntersecting) {
                    entry.target.classList.add("revealed");
                }
            });
        }, { threshold: 0.15 });
        revealItems.forEach((item) => observer.observe(item));
    }

    // Card number spacing.
    const cardNumberInput = document.getElementById("card-number");
    if (cardNumberInput) {
        cardNumberInput.addEventListener("input", () => {
            const digits = cardNumberInput.value.replace(/\D/g, "").slice(0, 16);
            cardNumberInput.value = digits.replace(/(\d{4})(?=\d)/g, "$1 ");
        });
    }

    // Expiry formatting MM/YY.
    const expiryInput = document.getElementById("expiry-date");
    if (expiryInput) {
        expiryInput.addEventListener("input", () => {
            const cleaned = expiryInput.value.replace(/\D/g, "").slice(0, 4);
            expiryInput.value = cleaned.length > 2
                ? `${cleaned.slice(0, 2)}/${cleaned.slice(2)}`
                : cleaned;
        });
    }

    // Global loading spinner for form submits.
    const loader = document.getElementById("global-loader");
    document.querySelectorAll("form").forEach((form) => {
        form.addEventListener("submit", () => {
            const spinner = form.querySelector(".spinner");
            if (spinner) {
                spinner.classList.remove("hidden");
            }
            if (loader) {
                loader.classList.remove("hidden");
            }
        });
    });

    // Simulated success modal before submitting payment form.
    const paymentForm = document.getElementById("payment-form");
    const paymentModal = document.getElementById("payment-success-modal");
    if (paymentForm && paymentModal) {
        paymentForm.addEventListener("submit", (event) => {
            const cvv = document.getElementById("cvv");
            const expiry = document.getElementById("expiry-date");
            const cardNumber = document.getElementById("card-number");
            const isValidCard = cardNumber && cardNumber.value.replace(/\s/g, "").length >= 16;
            const isValidExpiry = expiry && /^\d{2}\/\d{2}$/.test(expiry.value);
            const isValidCvv = cvv && /^\d{3,4}$/.test(cvv.value);
            if (!isValidCard || !isValidExpiry || !isValidCvv) {
                event.preventDefault();
                alert("Please enter valid payment details.");
                if (loader) loader.classList.add("hidden");
                return;
            }

            event.preventDefault();
            paymentModal.classList.remove("hidden");
            setTimeout(() => {
                paymentForm.submit();
            }, 1000);
        });
    }
});