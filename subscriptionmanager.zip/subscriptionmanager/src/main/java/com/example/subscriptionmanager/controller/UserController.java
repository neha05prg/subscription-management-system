package com.example.subscriptionmanager.controller;

import com.example.subscriptionmanager.model.Plan;
import com.example.subscriptionmanager.model.Subscription;
import com.example.subscriptionmanager.model.User;
import com.example.subscriptionmanager.service.PlanService;
import com.example.subscriptionmanager.service.SubscriptionService;
import com.example.subscriptionmanager.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.Comparator;
import java.util.List;

@Controller
@RequestMapping("/user")
public class UserController {

    @Autowired
    private UserService userService;

    @Autowired
    private SubscriptionService subscriptionService;

    @Autowired
    private PlanService planService;

    @PostMapping("/subscribe/{planId}")
    public String subscribe(@PathVariable Long planId, @AuthenticationPrincipal UserDetails userDetails) {
        Plan plan = planService.getPlanById(planId).orElse(null);
        User user = userService.getUserByEmail(userDetails.getUsername()).orElse(null);
        if (plan == null || user == null) {
            return "redirect:/user/dashboard?error=Unable+to+subscribe+to+selected+plan";
        }
        Subscription subscription = new Subscription();
        subscription.setUser(user);
        subscription.setPlan(plan);
        subscription.setPlanName(plan.getPlanName());
        subscription.setStartDate(LocalDate.now());
        subscription.setEndDate(LocalDate.now().plusMonths(plan.getDuration()));
        subscriptionService.addSubscription(subscription);
        return "redirect:/user/dashboard?success=Subscription+activated+for+" + plan.getPlanName().replace(" ", "+");
    }

    @GetMapping("/dashboard")
    public String userDashboard(@AuthenticationPrincipal UserDetails userDetails,
                                @RequestParam(required = false) String success,
                                @RequestParam(required = false) String error,
                                Model model) {
        User user = userService.getUserByEmail(userDetails.getUsername()).orElse(null);
        if (user == null) {
            return "redirect:/login?error";
        }
        List<Plan> plans = planService.getAllPlans();
        List<Subscription> subscriptions = subscriptionService.getSubscriptionsByUser(user);
        Subscription activeSubscription = subscriptions.stream()
                .filter(sub -> !sub.getEndDate().isBefore(LocalDate.now()))
                .max(Comparator.comparing(Subscription::getEndDate))
                .orElse(null);
        model.addAttribute("user", user);
        model.addAttribute("plans", plans);
        model.addAttribute("subscriptions", subscriptions);
        model.addAttribute("activeSubscription", activeSubscription);
        if (success != null) model.addAttribute("success", success);
        if (error != null) model.addAttribute("error", error);
        return "user-dashboard";
    }
}