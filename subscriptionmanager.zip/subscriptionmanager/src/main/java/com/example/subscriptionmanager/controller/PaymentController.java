package com.example.subscriptionmanager.controller;

import com.example.subscriptionmanager.model.Plan;
import com.example.subscriptionmanager.model.Subscription;
import com.example.subscriptionmanager.model.User;
import com.example.subscriptionmanager.service.PlanService;
import com.example.subscriptionmanager.service.SubscriptionService;
import com.example.subscriptionmanager.service.UserService;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.time.LocalDate;

@Controller
public class PaymentController {

    private final UserService userService;
    private final PlanService planService;
    private final SubscriptionService subscriptionService;

    public PaymentController(UserService userService, PlanService planService, SubscriptionService subscriptionService) {
        this.userService = userService;
        this.planService = planService;
        this.subscriptionService = subscriptionService;
    }

    @GetMapping("/payment")
    public String paymentPage(@RequestParam Long planId,
                              @AuthenticationPrincipal UserDetails userDetails,
                              Model model) {
        User user = userService.getUserByEmail(userDetails.getUsername()).orElse(null);
        Plan plan = planService.getPlanById(planId).orElse(null);
        if (user == null || plan == null) {
            return "redirect:/user/dashboard?error=Unable+to+load+payment+details";
        }
        model.addAttribute("user", user);
        model.addAttribute("plan", plan);
        return "payment";
    }

    @PostMapping("/payment/confirm")
    public String confirmPayment(@RequestParam Long planId,
                                 @RequestParam String cardHolderName,
                                 @RequestParam String cardNumber,
                                 @RequestParam String expiryDate,
                                 @RequestParam String cvv,
                                 @AuthenticationPrincipal UserDetails userDetails) {
        if (cardHolderName == null || cardHolderName.isBlank()
                || cardNumber == null || cardNumber.isBlank()
                || expiryDate == null || expiryDate.isBlank()
                || cvv == null || cvv.isBlank()) {
            return "redirect:/user/dashboard?error=Payment+failed.+Invalid+card+details";
        }

        User user = userService.getUserByEmail(userDetails.getUsername()).orElse(null);
        Plan plan = planService.getPlanById(planId).orElse(null);
        if (user == null || plan == null) {
            return "redirect:/user/dashboard?error=Payment+failed.+Invalid+plan+or+user";
        }

        LocalDate startDate = LocalDate.now();
        LocalDate endDate = startDate.plusMonths(plan.getDuration());

        Subscription subscription = new Subscription();
        subscription.setUser(user);
        subscription.setPlan(plan);
        subscription.setPlanName(plan.getPlanName());
        subscription.setStartDate(startDate);
        subscription.setEndDate(endDate);
        subscriptionService.addSubscription(subscription);

        return "redirect:/user/dashboard?success=Payment+successful.+Your+subscription+is+active+until+" + endDate;
    }
}
