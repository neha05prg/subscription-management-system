package com.example.subscriptionmanager.config;

import com.example.subscriptionmanager.model.Plan;
import com.example.subscriptionmanager.model.Role;
import com.example.subscriptionmanager.model.Subscription;
import com.example.subscriptionmanager.model.User;
import com.example.subscriptionmanager.repository.PlanRepository;
import com.example.subscriptionmanager.repository.SubscriptionRepository;
import com.example.subscriptionmanager.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDate;

@Component
public class DataInitializer implements CommandLineRunner {

    private final UserRepository userRepository;
    private final PlanRepository planRepository;
    private final SubscriptionRepository subscriptionRepository;
    private final PasswordEncoder passwordEncoder;

    public DataInitializer(UserRepository userRepository,
                           PlanRepository planRepository,
                           SubscriptionRepository subscriptionRepository,
                           PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.planRepository = planRepository;
        this.subscriptionRepository = subscriptionRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public void run(String... args) {
        Plan basic = planRepository.findByPlanName("Basic").orElseGet(() ->
                planRepository.save(new Plan("Basic", new BigDecimal("299.00"), 1)));
        Plan standard = planRepository.findByPlanName("Standard").orElseGet(() ->
                planRepository.save(new Plan("Standard", new BigDecimal("1499.00"), 6)));
        Plan premium = planRepository.findByPlanName("Premium").orElseGet(() ->
                planRepository.save(new Plan("Premium", new BigDecimal("2499.00"), 12)));

        User admin = userRepository.findByEmail("admin@submanager.com").orElseGet(() -> {
            User user = new User();
            user.setName("System Admin");
            user.setEmail("admin@submanager.com");
            user.setPassword(passwordEncoder.encode("admin123"));
            user.setRole(Role.ADMIN);
            return userRepository.save(user);
        });

        User demoUser = userRepository.findByEmail("user@submanager.com").orElseGet(() -> {
            User user = new User();
            user.setName("Demo User");
            user.setEmail("user@submanager.com");
            user.setPassword(passwordEncoder.encode("user123"));
            user.setRole(Role.USER);
            return userRepository.save(user);
        });

        if (subscriptionRepository.findByUser(demoUser).isEmpty()) {
            Subscription active = new Subscription();
            active.setUser(demoUser);
            active.setPlan(standard);
            active.setPlanName(standard.getPlanName());
            active.setStartDate(LocalDate.now().minusMonths(1));
            active.setEndDate(LocalDate.now().plusMonths(5));
            subscriptionRepository.save(active);

            Subscription expired = new Subscription();
            expired.setUser(demoUser);
            expired.setPlan(basic);
            expired.setPlanName(basic.getPlanName());
            expired.setStartDate(LocalDate.now().minusMonths(3));
            expired.setEndDate(LocalDate.now().minusMonths(2));
            subscriptionRepository.save(expired);
        }
    }
}
