package com.example.subscriptionmanager.model;

public enum Role {
    USER,
    ADMIN
}
