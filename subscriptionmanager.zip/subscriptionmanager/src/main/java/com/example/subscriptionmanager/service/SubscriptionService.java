package com.example.subscriptionmanager.service;

import com.example.subscriptionmanager.model.Subscription;
import com.example.subscriptionmanager.model.User;
import com.example.subscriptionmanager.repository.SubscriptionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SubscriptionService {

    @Autowired
    private SubscriptionRepository subscriptionRepository;

    public Subscription addSubscription(Subscription subscription) {
        return subscriptionRepository.save(subscription);
    }

    public List<Subscription> getAllSubscriptions() {
        return subscriptionRepository.findAll();
    }

    public List<Subscription> getSubscriptionsByUser(User user) {
        return subscriptionRepository.findByUserOrderByEndDateDesc(user);
    }

    public void deleteSubscription(Long id) {
        subscriptionRepository.deleteById(id);
    }
}