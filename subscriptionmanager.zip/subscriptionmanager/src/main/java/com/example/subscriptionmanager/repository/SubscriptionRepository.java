package com.example.subscriptionmanager.repository;

import com.example.subscriptionmanager.model.Subscription;
import com.example.subscriptionmanager.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface SubscriptionRepository extends JpaRepository<Subscription, Long> {
    List<Subscription> findByUser(User user);
    List<Subscription> findByUserOrderByEndDateDesc(User user);
}