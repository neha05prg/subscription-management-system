package com.example.subscriptionmanager.controller;

import com.example.subscriptionmanager.model.Plan;
import com.example.subscriptionmanager.model.Role;
import com.example.subscriptionmanager.model.Subscription;
import com.example.subscriptionmanager.model.User;
import com.example.subscriptionmanager.service.PlanService;
import com.example.subscriptionmanager.service.SubscriptionService;
import com.example.subscriptionmanager.service.UserService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
@RequestMapping("/admin")
public class AdminController {

    @Autowired
    private UserService userService;

    @Autowired
    private PlanService planService;

    @Autowired
    private SubscriptionService subscriptionService;

    @GetMapping("/dashboard")
    public String dashboard(@RequestParam(required = false) String success,
                            @RequestParam(required = false) String error,
                            Model model) {
        List<User> users = userService.getAllUsers();
        List<Plan> plans = planService.getAllPlans();
        List<Subscription> subscriptions = subscriptionService.getAllSubscriptions();
        model.addAttribute("users", users);
        model.addAttribute("plans", plans);
        model.addAttribute("subscriptions", subscriptions);
        if (!model.containsAttribute("planForm")) {
            model.addAttribute("planForm", new Plan());
        }
        if (!model.containsAttribute("userForm")) {
            model.addAttribute("userForm", new User());
        }
        if (success != null) model.addAttribute("success", success);
        if (error != null) model.addAttribute("error", error);
        return "admin-dashboard";
    }

    @PostMapping("/plans")
    public String createPlan(@Valid @ModelAttribute("planForm") Plan plan,
                             BindingResult result,
                             Model model) {
        if (result.hasErrors()) {
            dashboard(null, "Please enter valid plan details", model);
            return "admin-dashboard";
        }
        if (planService.getPlanByName(plan.getPlanName()).isPresent()) {
            dashboard(null, "Plan name already exists", model);
            return "admin-dashboard";
        }
        planService.savePlan(plan);
        return "redirect:/admin/dashboard?success=Plan+created+successfully";
    }

    @PostMapping("/plans/{id}")
    public String updatePlan(@PathVariable Long id,
                             @RequestParam String planName,
                             @RequestParam Integer duration,
                             @RequestParam java.math.BigDecimal price) {
        Plan existing = planService.getPlanById(id).orElse(null);
        if (existing == null) {
            return "redirect:/admin/dashboard?error=Plan+not+found";
        }
        existing.setPlanName(planName);
        existing.setDuration(duration);
        existing.setPrice(price);
        planService.savePlan(existing);
        return "redirect:/admin/dashboard?success=Plan+updated+successfully";
    }

    @GetMapping("/plans/delete/{id}")
    public String deletePlan(@PathVariable Long id) {
        planService.deletePlan(id);
        return "redirect:/admin/dashboard?success=Plan+deleted+successfully";
    }

    @PostMapping("/users/{id}")
    public String updateUser(@PathVariable Long id,
                             @RequestParam String name,
                             @RequestParam Role role) {
        User existing = userService.getUserById(id).orElse(null);
        if (existing == null) {
            return "redirect:/admin/dashboard?error=User+not+found";
        }
        existing.setName(name);
        existing.setRole(role);
        userService.save(existing);
        return "redirect:/admin/dashboard?success=User+updated+successfully";
    }

    @GetMapping("/users/delete/{id}")
    public String deleteUser(@PathVariable Long id) {
        userService.deleteUser(id);
        return "redirect:/admin/dashboard?success=User+deleted+successfully";
    }

    @GetMapping("/subscriptions/delete/{id}")
    public String deleteSubscription(@PathVariable Long id) {
        subscriptionService.deleteSubscription(id);
        return "redirect:/admin/dashboard?success=Subscription+deleted+successfully";
    }
}