package com.example.subscriptionmanager.controller;

import com.example.subscriptionmanager.model.Plan;
import com.example.subscriptionmanager.service.PlanService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class HomeController {

    @Autowired
    private PlanService planService;

    @GetMapping({"/", "/index"})
    public String index(Model model) {
        List<Plan> plans = planService.getAllPlans();
        model.addAttribute("plans", plans);
        return "index";
    }
}